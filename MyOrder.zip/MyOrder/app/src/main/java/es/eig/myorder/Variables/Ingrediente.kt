package es.eig.myorder.Variables

data class Ingrediente(
    val id:Int,
    val nombre: String,
    var cantidad:Int,
    val type:String
){

}
